package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBg = Color(0xFF0C0C0C)
val SurfaceDark = Color(0xFF161616)
val SurfaceContainerDark = Color(0xFF1E1E1E)
val GlowViolet = Color(0xFF8B5CF6)
val AccentViolet = Color(0xFF7C3AED)
val TextLight = Color(0xFFFFFFFF)
val TextGray = Color(0xFFE0E0E0)
val BorderWhiteSubtle = Color(0x0DFFFFFF)
val SuccessGreen = Color(0xFF007F5F)

