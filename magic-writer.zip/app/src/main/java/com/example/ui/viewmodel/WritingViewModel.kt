package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.db.DocumentEntity
import com.example.data.repository.Attachment
import com.example.data.repository.DocumentRepository
import com.example.data.repository.ProactiveSuggestion
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

data class WriterBlock(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val isRegenerating: Boolean = false,
    val hasSuggestion: Boolean = false,
    val suggestedText: String? = null
)

class WritingViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = DocumentRepository(db.documentDao())

    // All historic documents
    val documents: StateFlow<List<DocumentEntity>> = repository.allDocuments
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _currentDocument = MutableStateFlow<DocumentEntity?>(null)
    val currentDocument: StateFlow<DocumentEntity?> = _currentDocument.asStateFlow()

    // Interactive split paragraph blocks for the active document
    private val _blocks = MutableStateFlow<List<WriterBlock>>(emptyList())
    val blocks: StateFlow<List<WriterBlock>> = _blocks.asStateFlow()

    // Focused/Selected paragraph block
    private val _selectedBlockId = MutableStateFlow<String?>(null)
    val selectedBlockId: StateFlow<String?> = _selectedBlockId.asStateFlow()

    // Available attachments (combines default style briefs with user custom inputs)
    private val _attachments = MutableStateFlow<List<Attachment>>(repository.defaultAttachments)
    val attachments: StateFlow<List<Attachment>> = _attachments.asStateFlow()

    // Selected attachment names for initial AI generation
    private val _selectedAttachmentNames = MutableStateFlow<Set<String>>(emptySet())
    val selectedAttachmentNames: StateFlow<Set<String>> = _selectedAttachmentNames.asStateFlow()

    // Interactive API state flags
    private val _isInitialDrafting = MutableStateFlow(false)
    val isInitialDrafting: StateFlow<Boolean> = _isInitialDrafting.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _proactiveSuggestions = MutableStateFlow<List<ProactiveSuggestion>>(emptyList())
    val proactiveSuggestions: StateFlow<List<ProactiveSuggestion>> = _proactiveSuggestions.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    // Draft dialog inputs
    val draftPrompt = MutableStateFlow("")
    val newAttachmentName = MutableStateFlow("")
    val newAttachmentContent = MutableStateFlow("")

    private var autoSaveJob: kotlinx.coroutines.Job? = null
    private var titleSaveJob: kotlinx.coroutines.Job? = null

    init {
        // Load initial welcome document if none exists on startup
        viewModelScope.launch {
            try {
                val list = repository.allDocuments.first()
                if (list.isEmpty()) {
                    createAndLoadSampleDocument()
                } else if (_currentDocument.value == null) {
                    loadDocument(list.first())
                }
            } catch (e: Exception) {
                // Safe fallback in case first() collection gets interrupted or empty database issues
                createAndLoadSampleDocument()
            }
        }
    }

    private suspend fun createAndLoadSampleDocument() {
        val sampleText = """
            Welcome to Scribe, your magic offline-first collaborative writing canvas. This is not a typical text editor. Here, you craft articles, posts, or stories while AI acts as an inline developmental editor and thought partner.
            
            Double-tap or click any paragraph on this screen. A sleek context pane will slide up immediately. You can write simple natural feedback like "make this more poetic" or "rewrite with bullet points", and AI will rewrite precisely this paragraph, blending it perfectly with surrounding paragraphs.
            
            Click the "Scan prose" chip on the toolbar at any time. Scribe's proactive reviewer will analyze your phrasing for common pitfalls (wordiness, clichés, or passive expressions) and render immediate correction cards. Accept suggestions with an instant click to weave changes right in.
            
            To trigger a completely fresh start, tap the Floating Draft button in the bottom corner. Write an initial content brief, attach reference files, and let the AI build the initial structure for you. Enjoy the flow!
        """.trimIndent()

        val sampleDoc = DocumentEntity(
            title = "Introduction to Scribe AI",
            content = sampleText
        )
        val id = repository.insertDocument(sampleDoc)
        val loaded = sampleDoc.copy(id = id.toInt())
        loadDocument(loaded)
    }

    fun loadDocument(doc: DocumentEntity) {
        _currentDocument.value = doc
        // Split text content into blocks on paragraph breaks
        val splitBlocks = doc.content.split(Regex("\\R{2,}"))
            .filter { it.isNotBlank() }
            .map { WriterBlock(text = it.trim()) }
        _blocks.value = if (splitBlocks.isEmpty()) listOf(WriterBlock(text = "")) else splitBlocks
        _selectedBlockId.value = null
        _proactiveSuggestions.value = emptyList()
        _errorMessage.value = null
    }

    fun createAndNewDocument(title: String) {
        viewModelScope.launch {
            val freshDoc = DocumentEntity(
                title = title.ifBlank { "Untitled Document" },
                content = "Write freely here..."
            )
            val newId = repository.insertDocument(freshDoc)
            val updatedDoc = freshDoc.copy(id = newId.toInt())
            loadDocument(updatedDoc)
        }
    }

    fun selectBlock(id: String?) {
        _selectedBlockId.value = id
    }

    fun updateBlockText(id: String, newText: String) {
        val updated = _blocks.value.map { block ->
            if (block.id == id) block.copy(text = newText) else block
        }
        _blocks.value = updated
        autoSaveCurrentDocument(instant = false)
    }

    fun addBlockAfter(id: String) {
        val currentList = _blocks.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == id }
        val newBlock = WriterBlock(text = "")
        if (index != -1) {
            currentList.add(index + 1, newBlock)
        } else {
            currentList.add(newBlock)
        }
        _blocks.value = currentList
        _selectedBlockId.value = newBlock.id
        autoSaveCurrentDocument(instant = true)
    }

    fun deleteBlock(id: String) {
        val currentList = _blocks.value.toMutableList()
        if (currentList.size <= 1) {
            // Keep at least one empty block
            _blocks.value = listOf(WriterBlock(text = ""))
            _selectedBlockId.value = null
        } else {
            currentList.removeAll { it.id == id }
            _blocks.value = currentList
            _selectedBlockId.value = null
        }
        autoSaveCurrentDocument(instant = true)
    }

    private fun autoSaveCurrentDocument(instant: Boolean = false) {
        val doc = _currentDocument.value ?: return
        val joinedContent = _blocks.value.joinToString("\n\n") { it.text }
        val updatedDoc = doc.copy(content = joinedContent, updatedAt = System.currentTimeMillis())
        _currentDocument.value = updatedDoc
        
        autoSaveJob?.cancel()
        if (instant) {
            viewModelScope.launch {
                repository.updateDocument(updatedDoc)
            }
        } else {
            autoSaveJob = viewModelScope.launch {
                kotlinx.coroutines.delay(1000)
                repository.updateDocument(updatedDoc)
            }
        }
    }

    fun updateDocumentTitle(newTitle: String) {
        val doc = _currentDocument.value ?: return
        val updatedDoc = doc.copy(title = newTitle, updatedAt = System.currentTimeMillis())
        _currentDocument.value = updatedDoc
        
        titleSaveJob?.cancel()
        titleSaveJob = viewModelScope.launch {
            kotlinx.coroutines.delay(1000)
            repository.updateDocument(updatedDoc)
        }
    }

    fun toggleAttachmentSelection(name: String) {
        val currentSet = _selectedAttachmentNames.value.toMutableSet()
        if (currentSet.contains(name)) {
            currentSet.remove(name)
        } else {
            currentSet.add(name)
        }
        _selectedAttachmentNames.value = currentSet
    }

    fun addNewAttachment() {
        val name = newAttachmentName.value.trim()
        val content = newAttachmentContent.value.trim()
        if (name.isNotEmpty() && content.isNotEmpty()) {
            val formattedName = if (name.contains(".")) name else "$name.txt"
            val newAttach = Attachment(
                name = formattedName,
                description = "User created collaborative resource.",
                textContent = content
            )
            _attachments.value = _attachments.value + newAttach
            newAttachmentName.value = ""
            newAttachmentContent.value = ""
        }
    }

    fun deleteDocument(docId: Int) {
        viewModelScope.launch {
            repository.deleteDocumentById(docId)
            val remaining = documents.value
            if (remaining.isNotEmpty()) {
                val nextDoc = remaining.firstOrNull { it.id != docId }
                if (nextDoc != null) {
                    loadDocument(nextDoc)
                } else {
                    createAndLoadSampleDocument()
                }
            } else {
                createAndLoadSampleDocument()
            }
        }
    }

    fun clearErrorMessage() {
        _errorMessage.value = null
    }

    // --- Core AI Actions ---

    /**
     * AI Initial Draft Builder
     */
    fun buildInitialDraft() {
        val prompt = draftPrompt.value.trim()
        if (prompt.isEmpty()) return

        _isInitialDrafting.value = true
        _errorMessage.value = null

        // Collect attached materials
        val selectedFiles = _attachments.value.filter {
            _selectedAttachmentNames.value.contains(it.name)
        }

        viewModelScope.launch {
            val result = repository.generateInitialDraft(prompt, selectedFiles)
            _isInitialDrafting.value = false
            result.onSuccess { text ->
                val draftDoc = DocumentEntity(
                    title = "AI Draft - ${prompt.take(15)}...",
                    content = text
                )
                val newId = repository.insertDocument(draftDoc)
                val updatedDoc = draftDoc.copy(id = newId.toInt())
                loadDocument(updatedDoc)
                // Clear state inputs
                draftPrompt.value = ""
                _selectedAttachmentNames.value = emptySet()
            }.onFailure { error ->
                if (error.message == "invalid_api_key") {
                    _errorMessage.value = "Gemini API key is not configured. Please insert your key inside the AI Studio Secrets panel."
                } else {
                    _errorMessage.value = "Failed to compile draft: ${error.localizedMessage}"
                }
            }
        }
    }

    /**
     * Inline Paragraph Rewrite - Weaving user feedback seamlessly with adjacent blocks.
     */
    fun rewriteBlockInline(blockId: String, feedback: String) {
        if (feedback.trim().isEmpty()) return

        val blockList = _blocks.value
        val index = blockList.indexOfFirst { it.id == blockId }
        if (index == -1) return

        // Set loader on the block
        _blocks.value = blockList.map {
            if (it.id == blockId) it.copy(isRegenerating = true) else it
        }

        // Segment block context
        val beforeText = blockList.take(index).joinToString("\n\n") { it.text }
        val targetParagraph = blockList[index].text
        val afterText = blockList.drop(index + 1).joinToString("\n\n") { it.text }

        _errorMessage.value = null

        viewModelScope.launch {
            val result = repository.refineParagraph(beforeText, targetParagraph, afterText, feedback)
            _blocks.value = _blocks.value.map { block ->
                if (block.id == blockId) {
                    result.fold(
                        onSuccess = { rewrittenText ->
                            block.copy(
                                isRegenerating = false,
                                hasSuggestion = true,
                                suggestedText = rewrittenText
                            )
                        },
                        onFailure = { error ->
                            if (error.message == "invalid_api_key") {
                                _errorMessage.value = "Gemini API key is missing. Update the Secrets panel in AI Studio."
                            } else {
                                _errorMessage.value = "Refine failed: ${error.localizedMessage}"
                            }
                            block.copy(isRegenerating = false)
                        }
                    )
                } else {
                    block
                }
            }
        }
    }

    fun acceptBlockSuggestion(blockId: String) {
        _blocks.value = _blocks.value.map { block ->
            if (block.id == blockId && block.hasSuggestion && block.suggestedText != null) {
                block.copy(
                    text = block.suggestedText,
                    hasSuggestion = false,
                    suggestedText = null
                )
            } else {
                block
            }
        }
        autoSaveCurrentDocument(instant = true)
    }

    fun declineBlockSuggestion(blockId: String) {
        _blocks.value = _blocks.value.map { block ->
            if (block.id == blockId) {
                block.copy(
                    hasSuggestion = false,
                    suggestedText = null
                )
            } else {
                block
            }
        }
    }

    /**
     * Proactive Scanning - Generates in-line editorial recommendations
     */
    fun scanDocumentProactively() {
        val fullText = _blocks.value.joinToString("\n\n") { it.text }
        if (fullText.trim().length < 10) return

        _isScanning.value = true
        _errorMessage.value = null
        _proactiveSuggestions.value = emptyList()

        viewModelScope.launch {
            val result = repository.scanForProactiveSuggestions(fullText)
            _isScanning.value = false
            result.onSuccess { suggestions ->
                _proactiveSuggestions.value = suggestions
                if (suggestions.isEmpty()) {
                    _errorMessage.value = "Scan finished: Prose is looking perfectly optimal!"
                }
            }.onFailure { error ->
                if (error.message == "invalid_api_key") {
                    _errorMessage.value = "Prose review needs a Gemini API key. Add it in AI Studio."
                } else {
                    _errorMessage.value = "Proactive scan paused: ${error.localizedMessage}"
                }
            }
        }
    }

    /**
     * Applies a proactive correction directly inside its respective paragraph block.
     */
    fun applyProactiveSuggestion(suggestion: ProactiveSuggestion) {
        val updatedBlocks = _blocks.value.map { block ->
            if (block.text.contains(suggestion.originalText)) {
                val replacedText = block.text.replace(suggestion.originalText, suggestion.improvedText)
                block.copy(text = replacedText)
            } else {
                block
            }
        }
        _blocks.value = updatedBlocks
        _proactiveSuggestions.value = _proactiveSuggestions.value.filter { it != suggestion }
        autoSaveCurrentDocument(instant = true)
    }

    fun dismissProactiveSuggestion(suggestion: ProactiveSuggestion) {
        _proactiveSuggestions.value = _proactiveSuggestions.value.filter { it != suggestion }
    }
}
