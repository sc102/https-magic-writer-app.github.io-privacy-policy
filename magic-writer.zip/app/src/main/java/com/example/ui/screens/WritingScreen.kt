package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.db.DocumentEntity
import com.example.data.repository.Attachment
import com.example.data.repository.ProactiveSuggestion
import com.example.ui.viewmodel.WriterBlock
import com.example.ui.viewmodel.WritingViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WritingScreen(
    viewModel: WritingViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val documents by viewModel.documents.collectAsStateWithLifecycle()
    val currentDoc by viewModel.currentDocument.collectAsStateWithLifecycle()
    val blocks by viewModel.blocks.collectAsStateWithLifecycle()
    val selectedBlockId by viewModel.selectedBlockId.collectAsStateWithLifecycle()
    val attachments by viewModel.attachments.collectAsStateWithLifecycle()
    val selectedAttachNames by viewModel.selectedAttachmentNames.collectAsStateWithLifecycle()
    val isDrafting by viewModel.isInitialDrafting.collectAsStateWithLifecycle()
    val isScanning by viewModel.isScanning.collectAsStateWithLifecycle()
    val proactiveSuggestions by viewModel.proactiveSuggestions.collectAsStateWithLifecycle()
    val errorMessage by viewModel.errorMessage.collectAsStateWithLifecycle()

    var showDraftDialog by remember { mutableStateOf(false) }
    var showCreateDocDialog by remember { mutableStateOf(false) }
    var showAttachCreator by remember { mutableStateOf(false) }
    var newDocTitle by remember { mutableStateOf("") }

    // Multi-pane adaptive layout threshold
    BoxWithConstraints(modifier = modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars)) {
        val isWide = maxWidth > 720.dp

        if (isWide) {
            // Tablet/Wide screen permanent split panel
            Row(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
                // Fixed Drawer Sidebar Content on the left
                Box(
                    modifier = Modifier
                        .width(280.dp)
                        .fillMaxHeight()
                        .background(MaterialTheme.colorScheme.surfaceContainerLow)
                        .border(
                            BorderStroke(
                                1.dp,
                                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                            ),
                            shape = RoundedCornerShape(0.dp)
                        )
                ) {
                    SidebarContent(
                        documents = documents,
                        currentDoc = currentDoc,
                        onDocSelect = { viewModel.loadDocument(it) },
                        onNewClick = { showCreateDocDialog = true },
                        onDeleteClick = { viewModel.deleteDocument(it) }
                    )
                }

                // Writer canvas on the right
                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    MainCanvasArea(
                        currentDoc = currentDoc,
                        blocks = blocks,
                        selectedBlockId = selectedBlockId,
                        isScanning = isScanning,
                        errorMessage = errorMessage,
                        proactiveSuggestions = proactiveSuggestions,
                        onTitleChange = { viewModel.updateDocumentTitle(it) },
                        onBlockTextChange = { id, text -> viewModel.updateBlockText(id, text) },
                        onBlockSelect = { id -> viewModel.selectBlock(id) },
                        onAddBlockAfter = { id -> viewModel.addBlockAfter(id) },
                        onDeleteBlock = { id -> viewModel.deleteBlock(id) },
                        onInlineRewrite = { id, feedback -> viewModel.rewriteBlockInline(id, feedback) },
                        onAcceptSuggestion = { id -> viewModel.acceptBlockSuggestion(id) },
                        onDeclineSuggestion = { id -> viewModel.declineBlockSuggestion(id) },
                        onTriggerScan = { viewModel.scanDocumentProactively() },
                        onApplyProactive = { viewModel.applyProactiveSuggestion(it) },
                        onDismissProactive = { viewModel.dismissProactiveSuggestion(it) },
                        onClearError = { viewModel.clearErrorMessage() },
                        onDrawerMenuToggle = { /* Not needed in wide mode */ },
                        onOpenDraftWizard = { showDraftDialog = true },
                        showMenuButton = false
                    )
                }
            }
        } else {
            // Handheld Mobile View with interactive drawer
            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {
                    ModalDrawerSheet(
                        modifier = Modifier
                            .width(300.dp)
                            .fillMaxHeight(),
                        drawerContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                    ) {
                        SidebarContent(
                            documents = documents,
                            currentDoc = currentDoc,
                            onDocSelect = {
                                viewModel.loadDocument(it)
                                scope.launch { drawerState.close() }
                            },
                            onNewClick = {
                                showCreateDocDialog = true
                                scope.launch { drawerState.close() }
                            },
                            onDeleteClick = { viewModel.deleteDocument(it) }
                        )
                    }
                }
            ) {
                MainCanvasArea(
                    currentDoc = currentDoc,
                    blocks = blocks,
                    selectedBlockId = selectedBlockId,
                    isScanning = isScanning,
                    errorMessage = errorMessage,
                    proactiveSuggestions = proactiveSuggestions,
                    onTitleChange = { viewModel.updateDocumentTitle(it) },
                    onBlockTextChange = { id, text -> viewModel.updateBlockText(id, text) },
                    onBlockSelect = { id -> viewModel.selectBlock(id) },
                    onAddBlockAfter = { id -> viewModel.addBlockAfter(id) },
                    onDeleteBlock = { id -> viewModel.deleteBlock(id) },
                    onInlineRewrite = { id, feedback -> viewModel.rewriteBlockInline(id, feedback) },
                    onAcceptSuggestion = { id -> viewModel.acceptBlockSuggestion(id) },
                    onDeclineSuggestion = { id -> viewModel.declineBlockSuggestion(id) },
                    onTriggerScan = { viewModel.scanDocumentProactively() },
                    onApplyProactive = { viewModel.applyProactiveSuggestion(it) },
                    onDismissProactive = { viewModel.dismissProactiveSuggestion(it) },
                    onClearError = { viewModel.clearErrorMessage() },
                    onDrawerMenuToggle = { scope.launch { drawerState.open() } },
                    onOpenDraftWizard = { showDraftDialog = true },
                    showMenuButton = true
                )
            }
        }
    }

    // --- DIALOGS & OVERLAYS ---

    // 1. Initial AI drafting & attachments dialogue
    if (showDraftDialog) {
        Dialog(onDismissRequest = { showDraftDialog = false }) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight()
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                tonalElevation = 6.dp
            ) {
                Column(
                    modifier = Modifier
                        .padding(24.dp)
                        .fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "AI Draft Builder",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        IconButton(onClick = { showDraftDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close dialog")
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Describe what you want to write and attach structural design guides or briefs.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    val draftPromptText by viewModel.draftPrompt.collectAsStateWithLifecycle()
                    OutlinedTextField(
                        value = draftPromptText,
                        onValueChange = { viewModel.draftPrompt.value = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .testTag("draft_prompt_input"),
                        placeholder = { Text("e.g., Write a promotional sales pitch about our brainband...") },
                        label = { Text("AI prompt instruction") },
                        maxLines = 4,
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Reference Attachments",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Button(
                            onClick = { showAttachCreator = true },
                            colors = ButtonDefaults.textButtonColors(),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("New File", style = MaterialTheme.typography.labelMedium)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Attachment scroll row
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(vertical = 4.dp)
                    ) {
                        items(attachments) { file ->
                            val isSelected = selectedAttachNames.contains(file.name)
                            Card(
                                modifier = Modifier
                                    .width(140.dp)
                                    .clickable { viewModel.toggleAttachmentSelection(file.name) },
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) {
                                        MaterialTheme.colorScheme.primaryContainer
                                    } else {
                                        MaterialTheme.colorScheme.surfaceDim
                                    }
                                ),
                                border = if (isSelected) {
                                    BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
                                } else null
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.AttachFile,
                                            contentDescription = null,
                                            modifier = Modifier.size(14.dp),
                                            tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = file.name,
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = file.description,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontSize = 10.sp,
                                        maxLines = 2,
                                        lineHeight = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = {
                            viewModel.buildInitialDraft()
                            showDraftDialog = false
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("submit_draft_button"),
                        enabled = draftPromptText.isNotBlank() && !isDrafting,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (isDrafting) {
                            CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
                        } else {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Generate Master Draft", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // 2. Add New Attachment custom fileialog
    if (showAttachCreator) {
        Dialog(onDismissRequest = { showAttachCreator = false }) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight()
                    .padding(16.dp),
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHigh
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Create Collaborative File",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    val attachName by viewModel.newAttachmentName.collectAsStateWithLifecycle()
                    OutlinedTextField(
                        value = attachName,
                        onValueChange = { viewModel.newAttachmentName.value = it },
                        modifier = Modifier.fillMaxWidth().testTag("new_attachment_name"),
                        label = { Text("File Name (e.g., source.txt)") },
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    val attachContent by viewModel.newAttachmentContent.collectAsStateWithLifecycle()
                    OutlinedTextField(
                        value = attachContent,
                        onValueChange = { viewModel.newAttachmentContent.value = it },
                        modifier = Modifier.fillMaxWidth().height(140.dp).testTag("new_attachment_content"),
                        label = { Text("File Core Reference Text") },
                        maxLines = 6
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showAttachCreator = false }) {
                            Text("Cancel")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                viewModel.addNewAttachment()
                                showAttachCreator = false
                            },
                            enabled = attachName.isNotBlank() && attachContent.isNotBlank()
                        ) {
                            Text("Save File")
                        }
                    }
                }
            }
        }
    }

    // 3. New Document Creator Dialog
    if (showCreateDocDialog) {
        Dialog(onDismissRequest = { showCreateDocDialog = false }) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight()
                    .padding(16.dp),
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHigh
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "New Master Canvas",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = newDocTitle,
                        onValueChange = { newDocTitle = it },
                        modifier = Modifier.fillMaxWidth().testTag("new_doc_title_input"),
                        label = { Text("Document Title") },
                        singleLine = true,
                        placeholder = { Text("Untitled Scribe Concept") }
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showCreateDocDialog = false }) {
                            Text("Cancel")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                viewModel.createAndNewDocument(newDocTitle)
                                newDocTitle = ""
                                showCreateDocDialog = false
                            }
                        ) {
                            Text("Create")
                        }
                    }
                }
            }
        }
    }
}

// --- SUB-COMPONENTS ---

@Composable
fun SidebarContent(
    documents: List<DocumentEntity>,
    currentDoc: DocumentEntity?,
    onDocSelect: (DocumentEntity) -> Unit,
    onNewClick: () -> Unit,
    onDeleteClick: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .navigationBarsPadding()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Scribe AI",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Collaborative Hub",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(
                onClick = onNewClick,
                colors = IconButtonDefaults.iconButtonColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ),
                modifier = Modifier.testTag("create_new_doc_button")
            ) {
                Icon(
                    Icons.Default.Add,
                    contentDescription = "New Document",
                    tint = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "CANVAS REPOSITORIES",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
        )

        Spacer(modifier = Modifier.height(8.dp))

        if (documents.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No drafts written yet.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(documents) { doc ->
                    val isSelected = currentDoc?.id == doc.id
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onDocSelect(doc) }
                            .testTag("doc_item_${doc.id}"),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) {
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                            } else {
                                Color.Transparent
                            }
                        ),
                        border = if (isSelected) {
                            BorderStroke(1.2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                        } else null
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Book,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                    tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = doc.title,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        maxLines = 1,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = android.text.format.DateUtils.getRelativeTimeSpanString(doc.updatedAt).toString(),
                                        style = MaterialTheme.typography.bodySmall,
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                    )
                                }
                            }
                            // Delete button (hide if last welcome doc, but always allow deleting unless database empty)
                            IconButton(
                                onClick = { onDeleteClick(doc.id) },
                                modifier = Modifier.size(24.dp).testTag("delete_doc_${doc.id}")
                            ) {
                                Icon(
                                    Icons.Default.Delete,
                                    contentDescription = "Delete Document",
                                    tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f),
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MainCanvasArea(
    currentDoc: DocumentEntity?,
    blocks: List<WriterBlock>,
    selectedBlockId: String?,
    isScanning: Boolean,
    errorMessage: String?,
    proactiveSuggestions: List<ProactiveSuggestion>,
    onTitleChange: (String) -> Unit,
    onBlockTextChange: (String, String) -> Unit,
    onBlockSelect: (String?) -> Unit,
    onAddBlockAfter: (String) -> Unit,
    onDeleteBlock: (String) -> Unit,
    onInlineRewrite: (String, String) -> Unit,
    onAcceptSuggestion: (String) -> Unit,
    onDeclineSuggestion: (String) -> Unit,
    onTriggerScan: () -> Unit,
    onApplyProactive: (ProactiveSuggestion) -> Unit,
    onDismissProactive: (ProactiveSuggestion) -> Unit,
    onClearError: () -> Unit,
    onDrawerMenuToggle: () -> Unit,
    onOpenDraftWizard: () -> Unit,
    showMenuButton: Boolean
) {
    var feedbackTextMap = remember { mutableStateMapOf<String, String>() }

    Column(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        // 1. Sleek Navigation Header
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.background,
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (showMenuButton) {
                        IconButton(onClick = onDrawerMenuToggle, modifier = Modifier.testTag("drawer_menu_button")) {
                            Icon(Icons.Default.Menu, contentDescription = "Toggle Sidebar")
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                    }

                    // Violet glowing dot indicator & Draft title
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(Color(0xFF8B5CF6), shape = androidx.compose.foundation.shape.CircleShape)
                                .border(
                                    1.5.dp,
                                    Color(0xFF8B5CF6).copy(alpha = 0.5f),
                                    shape = androidx.compose.foundation.shape.CircleShape
                                )
                        )
                        Text(
                            text = "DRAFT: ${currentDoc?.title?.uppercase() ?: "MIDNIGHT SONATA"}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.2.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    // AI Draft Wizard Launcher
                    FilledTonalButton(
                        onClick = onOpenDraftWizard,
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                            contentColor = MaterialTheme.colorScheme.primary
                        ),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("draft_wizard_button")
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Draft Builder", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }

                // High intelligence analytical prose scanner button
                Button(
                    onClick = onTriggerScan,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.secondary,
                        contentColor = MaterialTheme.colorScheme.onSecondary
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("trigger_prose_scan_button"),
                    enabled = !isScanning
                ) {
                    if (isScanning) {
                        CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onSecondary)
                    } else {
                        Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Analyze Prose", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Error message banner or feedback alerts (Check if live keys, or scanning finished)
        AnimatedVisibility(
            visible = errorMessage != null,
            enter = slideInVertically() + fadeIn(),
            exit = slideOutVertically() + fadeOut()
        ) {
            errorMessage?.let { msg ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (msg.contains("Optimal", ignoreCase = true)) {
                            MaterialTheme.colorScheme.secondaryContainer
                        } else {
                            MaterialTheme.colorScheme.errorContainer
                        }
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = msg,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (msg.contains("Optimal", ignoreCase = true)) {
                                MaterialTheme.colorScheme.onSecondaryContainer
                            } else {
                                MaterialTheme.colorScheme.onErrorContainer
                            },
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = onClearError, modifier = Modifier.size(18.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Clear", modifier = Modifier.size(12.dp))
                        }
                    }
                }
            }
        }

        // 2. Prose Review Panel (Displays active inline warnings found by scanning)
        AnimatedVisibility(
            visible = proactiveSuggestions.isNotEmpty(),
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp, horizontal = 16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = Color(0xFF8B5CF6),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "PROACTIVE SUGGESTIONS (${proactiveSuggestions.size})",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF8B5CF6),
                            letterSpacing = 1.2.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(horizontal = 2.dp)
                ) {
                    items(proactiveSuggestions) { suggestion ->
                        Card(
                            modifier = Modifier
                                .width(300.dp)
                                .testTag("proactive_card_${suggestion.originalText.hashCode()}"),
                            colors = CardDefaults.cardColors(
                                containerColor = Color(0xFF161616)
                            ),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f))
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = null,
                                        tint = Color(0xFF8B5CF6).copy(alpha = 0.7f),
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "AI PROPOSAL",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color(0xFF8B5CF6),
                                        maxLines = 1,
                                        letterSpacing = 0.5.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Column(modifier = Modifier.fillMaxWidth()) {
                                    Text(
                                        text = "\"${suggestion.originalText}\"",
                                        style = MaterialTheme.typography.bodySmall,
                                        textDecoration = TextDecoration.LineThrough,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                        maxLines = 2
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "→ \"${suggestion.improvedText}\"",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF007F5F),
                                        maxLines = 2
                                    )
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    TextButton(
                                        onClick = { onDismissProactive(suggestion) },
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                                    ) {
                                        Text("Ignore", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Button(
                                        onClick = { onApplyProactive(suggestion) },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color(0xFF7C3AED)
                                        ),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                        modifier = Modifier.testTag("apply_suggestion_${suggestion.originalText.hashCode()}")
                                    ) {
                                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(10.dp), tint = Color.White)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Apply", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. Document Base Board
        if (currentDoc == null) {
            Box(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
            ) {
                // Title Field
                var docTitle by remember(currentDoc.id) { mutableStateOf(currentDoc.title) }
                BasicTextField(
                    value = docTitle,
                    onValueChange = {
                        docTitle = it
                        onTitleChange(it)
                    },
                    textStyle = TextStyle(
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onBackground,
                        fontFamily = FontFamily.SansSerif
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp, bottom = 24.dp)
                        .testTag("document_title_input"),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done)
                )

                // Subtitle/Wordcount header
                val totalWords = blocks.sumOf { it.text.split(Regex("\\s+")).filter { w -> w.isNotBlank() }.size }
                Text(
                    text = "${blocks.size} paragraphs • $totalWords words • Distraction-free active canvas",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Divider(
                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                // Render blocks as interactive canvas items
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .testTag("writing_canvas_list"),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(bottom = 96.dp)
                ) {
                    items(items = blocks, key = { it.id }) { block ->
                        val isSelected = selectedBlockId == block.id
                        val feedback = feedbackTextMap[block.id] ?: ""

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (isSelected) {
                                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                                    } else {
                                        Color.Transparent
                                    }
                                )
                                .border(
                                    border = if (isSelected) {
                                        BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.6f))
                                    } else {
                                        BorderStroke(0.dp, Color.Transparent)
                                    },
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .padding(12.dp)
                                .clickable { onBlockSelect(block.id) }
                        ) {
                            if (block.isRegenerating) {
                                // Mini block skeleton loader
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = "Weaving changes on timeline, please wait...",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            } else if (block.hasSuggestion && block.suggestedText != null) {
                                // COMPARATIVE EDIT STATE (DIFFERENCE VIEWER)
                                Column(modifier = Modifier.fillMaxWidth()) {
                                    Text(
                                        text = "AI COLLABORATIVE REVISION",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(bottom = 6.dp)
                                    )
                                    // Original crossing out
                                    Text(
                                        text = block.text,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontSize = 15.sp,
                                        textDecoration = TextDecoration.LineThrough,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                        modifier = Modifier.padding(bottom = 4.dp)
                                    )
                                    // Dynamic suggestion highlights
                                    Text(
                                        text = block.suggestedText,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFF007F5F) // Soft success green
                                    )

                                    Spacer(modifier = Modifier.height(12.dp))

                                    // Action bar inside the comparative block
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End
                                    ) {
                                        OutlinedButton(
                                            onClick = { onDeclineSuggestion(block.id) },
                                            modifier = Modifier.testTag("reject_revision_${block.id}"),
                                            contentPadding = PaddingValues(horizontal = 12.dp)
                                        ) {
                                            Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Decline", fontSize = 12.sp)
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Button(
                                            onClick = { onAcceptSuggestion(block.id) },
                                            modifier = Modifier.testTag("accept_revision_${block.id}"),
                                            contentPadding = PaddingValues(horizontal = 12.dp)
                                        ) {
                                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Accept Changes", fontSize = 12.sp)
                                        }
                                    }
                                }
                            } else {
                                // STANDARD PARAGRAPH BLOCK
                                BasicTextField(
                                    value = block.text,
                                    onValueChange = { onBlockTextChange(block.id, it) },
                                    textStyle = TextStyle(
                                        fontSize = 16.sp,
                                        lineHeight = 24.sp,
                                        color = MaterialTheme.colorScheme.onBackground,
                                        fontFamily = FontFamily.Serif
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("paragraph_box_${block.id}"),
                                    decorationBox = { innerTextField ->
                                        if (block.text.isEmpty()) {
                                            Text(
                                                text = "Begin writing or tap here...",
                                                style = TextStyle(
                                                    fontSize = 16.sp,
                                                    lineHeight = 24.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                                                    fontFamily = FontFamily.Serif
                                                )
                                            )
                                        }
                                        innerTextField()
                                    }
                                )

                                // EXPLICIT EDIT SUB-PANE
                                AnimatedVisibility(
                                    visible = isSelected,
                                    enter = expandVertically() + fadeIn(),
                                    exit = shrinkVertically() + fadeOut()
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(top = 12.dp)
                                    ) {
                                        Divider(
                                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
                                            modifier = Modifier.padding(bottom = 12.dp)
                                        )

                                        // Inline editing prompt input
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            OutlinedTextField(
                                                value = feedback,
                                                onValueChange = { feedbackTextMap[block.id] = it },
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .testTag("block_prompt_${block.id}"),
                                                placeholder = { Text("e.g., make it shorter", fontSize = 13.sp) },
                                                label = { Text("How should AI rewrite this block?", fontSize = 11.sp) },
                                                shape = RoundedCornerShape(10.dp),
                                                singleLine = true,
                                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                                                keyboardActions = KeyboardActions(onAny = {
                                                    onInlineRewrite(block.id, feedback)
                                                })
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            IconButton(
                                                onClick = {
                                                    onInlineRewrite(block.id, feedback)
                                                },
                                                enabled = feedback.isNotBlank(),
                                                colors = IconButtonDefaults.filledIconButtonColors(
                                                    containerColor = MaterialTheme.colorScheme.primary,
                                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                                ),
                                                modifier = Modifier.size(48.dp).testTag("block_submit_rewrite_${block.id}")
                                            ) {
                                                Icon(
                                                    Icons.Default.AutoAwesome,
                                                    contentDescription = "Rewrite paragraph"
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(8.dp))

                                        // Action controls: insert next block or remove block
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row {
                                                FilledTonalButton(
                                                    onClick = { onAddBlockAfter(block.id) },
                                                    shape = RoundedCornerShape(10.dp),
                                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                                    modifier = Modifier.sizeIn(minHeight = 32.dp).testTag("add_below_${block.id}")
                                                ) {
                                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(12.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("Paragraph below", fontSize = 12.sp)
                                                }
                                            }

                                            IconButton(
                                                onClick = { onDeleteBlock(block.id) },
                                                modifier = Modifier.size(32.dp).testTag("delete_block_${block.id}")
                                            ) {
                                                Icon(
                                                    Icons.Default.Delete,
                                                    contentDescription = "Delete Block",
                                                    tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Sticky Bottom Status Toolbar inspired by Sophisticated Dark HTML
                val footerTotalWords = blocks.sumOf { it.text.split(Regex("\\s+")).filter { w -> w.isNotBlank() }.size }
                val footerReadTime = maxOf(1, (footerTotalWords / 200))
                
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF161616),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Word Count
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Book,
                                contentDescription = null,
                                tint = Color(0xFF8B5CF6),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "WORDS: $footerTotalWords",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                letterSpacing = 1.sp
                            )
                        }
                        
                        // Reading time
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = null,
                                tint = Color(0xFF8B5CF6),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "READ TIME: ${footerReadTime}M",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                letterSpacing = 1.sp
                            )
                        }

                        // Synced status
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .background(Color(0xFF007F5F), shape = androidx.compose.foundation.shape.CircleShape)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "SYNCED",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF007F5F),
                                letterSpacing = 1.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
