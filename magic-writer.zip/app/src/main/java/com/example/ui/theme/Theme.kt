package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = GlowViolet,
    secondary = AccentViolet,
    tertiary = SuccessGreen,
    background = DarkBg,
    surface = SurfaceDark,
    surfaceContainer = SurfaceContainerDark,
    onPrimary = TextLight,
    onSecondary = TextLight,
    onBackground = TextGray,
    onSurface = TextGray,
    onSurfaceVariant = Color(0xFF9E9E9E),
    outline = Color(0xFF424242),
    outlineVariant = BorderWhiteSubtle
  )

private val LightColorScheme = DarkColorScheme


@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = DarkColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
